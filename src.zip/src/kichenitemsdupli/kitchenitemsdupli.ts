export interface Mykitchen1
{
    vegetableid:number,
    vegetablename:string,
    vegetablecost:number,
    vegetableimg:string,
    vegetablequantity:number,
    totalprice:number
}